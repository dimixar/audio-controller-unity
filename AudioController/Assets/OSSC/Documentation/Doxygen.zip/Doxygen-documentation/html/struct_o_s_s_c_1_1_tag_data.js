var struct_o_s_s_c_1_1_tag_data =
[
    [ "ID", "struct_o_s_s_c_1_1_tag_data.html#ab65251c5bb43cb3089e5d8eb39dc6c24", null ],
    [ "name", "struct_o_s_s_c_1_1_tag_data.html#ab6c496d15b2caaafcd916a699a208057", null ]
];