var class_o_s_s_c_1_1_sound_tags =
[
    [ "SoundTags", "class_o_s_s_c_1_1_sound_tags.html#ab51e048016a41d1bd7caeee46516bbbb", null ],
    [ "GetTagDataByID", "class_o_s_s_c_1_1_sound_tags.html#a57a4b3c2be94b62c20d8d94a396b9084", null ],
    [ "GetTagDataByName", "class_o_s_s_c_1_1_sound_tags.html#a2850f4fc59e5f4e7778523cb4c09a100", null ],
    [ "GetTagIDByName", "class_o_s_s_c_1_1_sound_tags.html#a9112f075fee1b4082a9d4e8925d8589a", null ],
    [ "GetTagNameByID", "class_o_s_s_c_1_1_sound_tags.html#a755dc102f8bcdceac0965e2796641b0c", null ],
    [ "RemoveByTag", "class_o_s_s_c_1_1_sound_tags.html#a66bc68e7fd53adde3afa1d62cbd0a24c", null ],
    [ "SetTag", "class_o_s_s_c_1_1_sound_tags.html#ae124cedb161e12e811c649edca849392", null ],
    [ "ToArray", "class_o_s_s_c_1_1_sound_tags.html#ae1b20b32bb24d1370a8ea473648331be", null ],
    [ "ToArrayIDs", "class_o_s_s_c_1_1_sound_tags.html#a59700e648afa5750967e9afd9a10c6bb", null ],
    [ "ToArrayNames", "class_o_s_s_c_1_1_sound_tags.html#a7b30595a8a7f74acffb1507f830e03f2", null ]
];