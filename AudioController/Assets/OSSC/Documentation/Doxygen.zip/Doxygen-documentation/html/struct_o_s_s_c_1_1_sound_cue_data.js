var struct_o_s_s_c_1_1_sound_cue_data =
[
    [ "audioPrefab", "struct_o_s_s_c_1_1_sound_cue_data.html#a93cc717995b01455aa50c4639b4159b2", null ],
    [ "categoriesForSounds", "struct_o_s_s_c_1_1_sound_cue_data.html#a702e616a4b67930d80932938ba657673", null ],
    [ "categoryVolumes", "struct_o_s_s_c_1_1_sound_cue_data.html#a8bdcc9cd3d93b05d9488df0a1a2188d5", null ],
    [ "fadeInTime", "struct_o_s_s_c_1_1_sound_cue_data.html#ae975c3a3cc0b8a4c699817988d0ecb29", null ],
    [ "fadeOutTime", "struct_o_s_s_c_1_1_sound_cue_data.html#a50bba0b13ae10cf8019fa423fd0eda5b", null ],
    [ "isFadeIn", "struct_o_s_s_c_1_1_sound_cue_data.html#af686a12515811f31e0b8dc41762c48c9", null ],
    [ "isFadeOut", "struct_o_s_s_c_1_1_sound_cue_data.html#af8ea26b6fa23fc13d21a582aaaadc374", null ],
    [ "isLooped", "struct_o_s_s_c_1_1_sound_cue_data.html#a2d5f48fa175fb37eac096f985f281e08", null ],
    [ "sounds", "struct_o_s_s_c_1_1_sound_cue_data.html#a00e50f1a08e6fb547ef11ba0ddd41167", null ]
];