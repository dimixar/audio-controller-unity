var hierarchy =
[
    [ "OSSC.Model.CategoryItem", "class_o_s_s_c_1_1_model_1_1_category_item.html", null ],
    [ "OSSC.CueManager", "class_o_s_s_c_1_1_cue_manager.html", null ],
    [ "OSSC.Model.CustomRange", "class_o_s_s_c_1_1_model_1_1_custom_range.html", null ],
    [ "Editor", null, [
      [ "OSSC.Editor.SoundControllerEditor", "class_o_s_s_c_1_1_editor_1_1_sound_controller_editor.html", null ],
      [ "OSSC.Editor.SoundObjectEditor", "class_o_s_s_c_1_1_editor_1_1_sound_object_editor.html", null ]
    ] ],
    [ "IPoolable", "interface_i_poolable.html", [
      [ "OSSC.SoundObject", "class_o_s_s_c_1_1_sound_object.html", null ]
    ] ],
    [ "OSSC.ISoundCue", "interface_o_s_s_c_1_1_i_sound_cue.html", [
      [ "OSSC.SoundCue", "class_o_s_s_c_1_1_sound_cue.html", null ],
      [ "OSSC.SoundCueProxy", "class_o_s_s_c_1_1_sound_cue_proxy.html", null ]
    ] ],
    [ "MonoBehaviour", null, [
      [ "ObjectPool", "class_object_pool.html", null ],
      [ "OSSC.SoundController", "class_o_s_s_c_1_1_sound_controller.html", null ],
      [ "OSSC.SoundObject", "class_o_s_s_c_1_1_sound_object.html", null ]
    ] ],
    [ "OSSC.PlaySoundSettings", "struct_o_s_s_c_1_1_play_sound_settings.html", null ],
    [ "PrefabBasedPool", "class_prefab_based_pool.html", null ],
    [ "ScriptableObject", null, [
      [ "OSSC.Model.SoundControllerData", "class_o_s_s_c_1_1_model_1_1_sound_controller_data.html", null ]
    ] ],
    [ "OSSC.SoundCueData", "struct_o_s_s_c_1_1_sound_cue_data.html", null ],
    [ "OSSC.Model.SoundItem", "class_o_s_s_c_1_1_model_1_1_sound_item.html", null ],
    [ "OSSC.SoundTags", "class_o_s_s_c_1_1_sound_tags.html", null ],
    [ "OSSC.TagData", "struct_o_s_s_c_1_1_tag_data.html", null ]
];