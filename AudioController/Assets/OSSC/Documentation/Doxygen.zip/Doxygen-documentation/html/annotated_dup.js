var annotated_dup =
[
    [ "OSSC", "namespace_o_s_s_c.html", "namespace_o_s_s_c" ],
    [ "IPoolable", "interface_i_poolable.html", "interface_i_poolable" ],
    [ "ObjectPool", "class_object_pool.html", "class_object_pool" ],
    [ "PrefabBasedPool", "class_prefab_based_pool.html", "class_prefab_based_pool" ]
];