var class_prefab_based_pool =
[
    [ "PrefabBasedPool", "class_prefab_based_pool.html#a8ca94531a907bc7741a78f71abf2bd56", null ],
    [ "Despawn", "class_prefab_based_pool.html#afe5e4e7a6105bb3f0cb102be09bc175c", null ],
    [ "GetFreeObject", "class_prefab_based_pool.html#a2afd1c2a279b722c3457ddc9e91e44cd", null ],
    [ "parent", "class_prefab_based_pool.html#af717425a886962f6f7411e98482d837a", null ],
    [ "pool", "class_prefab_based_pool.html#a079534c907978bfc299db83fb83a3610", null ],
    [ "prefab", "class_prefab_based_pool.html#a96acd07411585f65badbcff24651da47", null ]
];