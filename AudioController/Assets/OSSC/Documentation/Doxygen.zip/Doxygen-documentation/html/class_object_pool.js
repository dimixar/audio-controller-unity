var class_object_pool =
[
    [ "GetFreeObject", "class_object_pool.html#ab48219db71bbf021f1e8dccbeefdaa7a", null ],
    [ "pools", "class_object_pool.html#a6f9915efc836c870cd2fc482c29033cb", null ]
];