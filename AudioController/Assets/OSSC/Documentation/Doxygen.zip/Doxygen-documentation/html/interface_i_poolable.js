var interface_i_poolable =
[
    [ "IsFree", "interface_i_poolable.html#a4c23825b033629c5390fff6f4dbd0d67", null ],
    [ "pool", "interface_i_poolable.html#a03ed1af8656254bd9b6d7bf29d99f03d", null ]
];