var searchData=
[
  ['max',['max',['../class_o_s_s_c_1_1_model_1_1_custom_range.html#a241040de3e7d9e959526d3d1880f2eb4',1,'OSSC::Model::CustomRange']]],
  ['min',['min',['../class_o_s_s_c_1_1_model_1_1_custom_range.html#aa9a5c869c0b50cb4f85d3d07740a6b7b',1,'OSSC::Model::CustomRange']]],
  ['mixer',['mixer',['../class_o_s_s_c_1_1_model_1_1_sound_item.html#aa4a2d303318cffc605cbf2222a4208c4',1,'OSSC::Model::SoundItem']]]
];
