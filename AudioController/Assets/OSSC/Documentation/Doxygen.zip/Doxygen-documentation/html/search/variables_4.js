var searchData=
[
  ['id',['ID',['../struct_o_s_s_c_1_1_tag_data.html#ab65251c5bb43cb3089e5d8eb39dc6c24',1,'OSSC::TagData']]],
  ['isfadein',['isFadeIn',['../struct_o_s_s_c_1_1_sound_cue_data.html#af686a12515811f31e0b8dc41762c48c9',1,'OSSC::SoundCueData']]],
  ['isfadeout',['isFadeOut',['../struct_o_s_s_c_1_1_sound_cue_data.html#af8ea26b6fa23fc13d21a582aaaadc374',1,'OSSC::SoundCueData']]],
  ['islooped',['isLooped',['../struct_o_s_s_c_1_1_play_sound_settings.html#a2d5084ee73531a7471c330dceeef2844',1,'OSSC.PlaySoundSettings.isLooped()'],['../struct_o_s_s_c_1_1_sound_cue_data.html#a2d5f48fa175fb37eac096f985f281e08',1,'OSSC.SoundCueData.isLooped()']]],
  ['ismute',['isMute',['../class_o_s_s_c_1_1_model_1_1_category_item.html#aaf7b7f35e3f3f54480f1bb207dadc85c',1,'OSSC::Model::CategoryItem']]],
  ['israndompitch',['isRandomPitch',['../class_o_s_s_c_1_1_model_1_1_sound_item.html#a16ee26958af3ced87af614e85ac699b3',1,'OSSC::Model::SoundItem']]],
  ['israndomvolume',['isRandomVolume',['../class_o_s_s_c_1_1_model_1_1_sound_item.html#af1e33eee28ad1c928a140728074466c8',1,'OSSC::Model::SoundItem']]],
  ['items',['items',['../class_o_s_s_c_1_1_model_1_1_sound_controller_data.html#a1397c4543be2e2a75de22711eb6d98d7',1,'OSSC::Model::SoundControllerData']]]
];
