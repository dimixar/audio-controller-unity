var searchData=
[
  ['tagid',['tagID',['../class_o_s_s_c_1_1_model_1_1_sound_item.html#a5f9b97c1516aaaf419918b656134cf11',1,'OSSC::Model::SoundItem']]],
  ['tagname',['tagName',['../struct_o_s_s_c_1_1_play_sound_settings.html#acfc6858624845c494e51ea20e3a3c4ca',1,'OSSC::PlaySoundSettings']]]
];
