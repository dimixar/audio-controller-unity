var searchData=
[
  ['tagdata',['TagData',['../struct_o_s_s_c_1_1_tag_data.html',1,'OSSC']]]
];
