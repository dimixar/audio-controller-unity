var searchData=
[
  ['init',['Init',['../struct_o_s_s_c_1_1_play_sound_settings.html#a32ea50776588f1b817e60bbfaa586135',1,'OSSC::PlaySoundSettings']]],
  ['isfree',['IsFree',['../interface_i_poolable.html#a4c23825b033629c5390fff6f4dbd0d67',1,'IPoolable.IsFree()'],['../class_o_s_s_c_1_1_sound_object.html#ad4e8fb53c5c50fc76b4ebba8258cebc2',1,'OSSC.SoundObject.IsFree()']]]
];
