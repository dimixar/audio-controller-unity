var searchData=
[
  ['oninspectorgui',['OnInspectorGUI',['../class_o_s_s_c_1_1_editor_1_1_sound_controller_editor.html#aa06b29dd87e966d39ab10c5e3d0d416f',1,'OSSC.Editor.SoundControllerEditor.OnInspectorGUI()'],['../class_o_s_s_c_1_1_editor_1_1_sound_object_editor.html#a6d0e8aa8b909afa9b7fafe53d567da22',1,'OSSC.Editor.SoundObjectEditor.OnInspectorGUI()']]]
];
