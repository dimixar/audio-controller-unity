var searchData=
[
  ['name',['name',['../class_o_s_s_c_1_1_model_1_1_category_item.html#a96ec599b842c4ef0b40dfe200cc6d848',1,'OSSC.Model.CategoryItem.name()'],['../class_o_s_s_c_1_1_model_1_1_sound_item.html#a822f1287f58da222f623a3cecfb10d5f',1,'OSSC.Model.SoundItem.name()'],['../struct_o_s_s_c_1_1_play_sound_settings.html#a98f6c92c2217d64b12c7fc9bdc0a45df',1,'OSSC.PlaySoundSettings.name()'],['../struct_o_s_s_c_1_1_tag_data.html#ab6c496d15b2caaafcd916a699a208057',1,'OSSC.TagData.name()']]],
  ['names',['names',['../struct_o_s_s_c_1_1_play_sound_settings.html#a2aa59e8bc408945b6ec0d92bca05c329',1,'OSSC::PlaySoundSettings']]]
];
