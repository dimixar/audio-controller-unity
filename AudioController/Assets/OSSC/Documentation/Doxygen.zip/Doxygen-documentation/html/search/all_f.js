var searchData=
[
  ['volume',['volume',['../class_o_s_s_c_1_1_model_1_1_sound_item.html#a28ddfa8a83c282b6c12c5d41b684cd2a',1,'OSSC::Model::SoundItem']]],
  ['volumerange',['volumeRange',['../class_o_s_s_c_1_1_model_1_1_sound_item.html#ab402a1e54dcef68a1d591c9ed3f4a924',1,'OSSC::Model::SoundItem']]]
];
