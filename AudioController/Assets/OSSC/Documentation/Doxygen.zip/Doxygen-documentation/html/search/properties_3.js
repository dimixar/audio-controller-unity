var searchData=
[
  ['id',['ID',['../interface_o_s_s_c_1_1_i_sound_cue.html#abd28946aa50c458f6eb621967d79f720',1,'OSSC.ISoundCue.ID()'],['../class_o_s_s_c_1_1_sound_cue.html#a626b334e70a67c8bcc3cf381eee11c81',1,'OSSC.SoundCue.ID()'],['../class_o_s_s_c_1_1_sound_cue_proxy.html#ad8580d3164859d120397ee3bcd914804',1,'OSSC.SoundCueProxy.ID()'],['../class_o_s_s_c_1_1_sound_object.html#a6415e447654838be22caec4eee6f92a0',1,'OSSC.SoundObject.ID()']]],
  ['isdespawnonfinishedplaying',['isDespawnOnFinishedPlaying',['../class_o_s_s_c_1_1_sound_object.html#ac6b584853fea8dea8dce985eecb32486',1,'OSSC::SoundObject']]],
  ['isplaying',['IsPlaying',['../interface_o_s_s_c_1_1_i_sound_cue.html#a96b2e2e32f15c2549b098db79fbcb738',1,'OSSC.ISoundCue.IsPlaying()'],['../class_o_s_s_c_1_1_sound_cue.html#aee8c6fadee4902cfe71045f30338b939',1,'OSSC.SoundCue.IsPlaying()'],['../class_o_s_s_c_1_1_sound_cue_proxy.html#a114b9093711335925373812283d0b212',1,'OSSC.SoundCueProxy.IsPlaying()']]]
];
