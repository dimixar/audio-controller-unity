var searchData=
[
  ['_5fdatabase',['_database',['../class_o_s_s_c_1_1_sound_controller.html#aabb24fe3eb8dd032fb150723fb077883',1,'OSSC::SoundController']]],
  ['_5fdefaultprefab',['_defaultPrefab',['../class_o_s_s_c_1_1_sound_controller.html#a2b3b8065d58044d3923c734cd1cc1d15',1,'OSSC::SoundController']]]
];
